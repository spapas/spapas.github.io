""":mod:`sassutils` --- Additional utilities related to SASS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This package provides several additional utilities related to SASS
which depends on libsass core (:mod:`sass` module).

"""
